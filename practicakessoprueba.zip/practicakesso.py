#Crear una clase Pokemon que pueda cargar y guardar sus datos en un archivo de texto.
#Atributos de la clase Pokemon: Nombre, Tipo, Fuerza, Agilidad, Inteligencia, Nivel.

#Ejemplo:
#Nombre: Pikachu, Tipo: Electrico, Fuerza: 10, Agilidad: 5, Inteligencia: 15, Nivel: 3

#Usen el separador que quieran y lo agregan como deseen

class pokemon:
    def __init__(self, pnombre, ptipo, pfuerza, pagilidad, pinteligencia, pnivel):
       self.nombre = pnombre
       self.tipo = ptipo
       self.fuerza = pfuerza
       self.agilidad = pagilidad
       self.inteligencia = pinteligencia
       self.nivel = pnivel

    def guardar(self, archivo):
        with open(archivo, 'w') as f:
            f.write(f'{self.nombre},{self.tipo},{self.fuerza},{self.agilidad},{self.inteligencia},{self.nivel}\n')

    @classmethod
    def cargar(cls,archivo):
        with open(archivo, 'r') as f:
            line = f.readline().strip()
            pnombre, ptipo, pfuerza, pagilidad, pinteligencia, pnivel = line.split(',')
            return cls(
                nombre=pnombre,
                tipo=ptipo,
                fuerza=int(pfuerza),
                agilidad=int(pagilidad),
                inteligencia=int(pinteligencia),
                nivel=int(pnivel)
            )
    def __int__(self):
        return(f'Nombre: {self.nombre}\n'
               f'Tipo: {self.tipo}\n'
               f'Fuerza: {self.fuerza}\n'
               f'Agilidad: {self.agilidad}\n'
               f'Inteligencia: {self.inteligencia}\n'
               f'Nivel: {self.nivel}')

if __name__ == "__main__":
    pikachu = pokemon("Pikachu", "Electrico", 10, 5, 15, 3)
    print(pikachu_cargado)




